﻿Public Class Form1
    Dim gender As String
    Dim ans1 As String
    Dim ans2 As String
    Dim ans3 As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter("C:\test.txt", False)
        file.WriteLine(vbTab + vbTab + Label1.Text)
        file.WriteLine(vbTab + "")
        file.WriteLine(Label14.Text)
        file.WriteLine(vbTab + Label2.Text + TextBox1.Text + vbTab + vbTab + Label9.Text + gender)
        file.WriteLine(vbTab + Label4.Text + TextBox2.Text + vbTab + Label10.Text + TextBox7.Text)
        file.WriteLine(vbTab + Label7.Text + TextBox3.Text + vbTab + Label3.Text + TextBox5.Text)
        file.WriteLine(vbTab + Label6.Text + TextBox4.Text + vbTab + Label8.Text + TextBox6.Text)
        file.WriteLine(vbTab + Label5.Text + TextBox8.Text)
        file.WriteLine(vbTab + "")
        file.WriteLine(Label12.Text)
        file.WriteLine(vbTab + Label11.Text + ans1)
        file.WriteLine(vbTab + Label13.Text + ans2)
        file.WriteLine(vbTab + Label15.Text + TextBox9.Text)
        file.WriteLine(vbTab + Label16.Text + ans3)
        file.Close()
        MessageBox.Show("Data is now saved!")
    End Sub

    Private Sub TextBox10_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Application.Exit()
    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click

    End Sub

    Private Sub radbtn2_CheckedChanged(sender As Object, e As EventArgs) Handles radbtn2.CheckedChanged
        If radbtn2.Checked = True Then
            gender = "Female"
        End If
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        If RadioButton3.Checked = True Then
            ans1 = " YES "
        End If
    End Sub

    Private Sub RadioButton6_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton6.CheckedChanged
        If RadioButton6.Checked = True Then
            ans2 = " YES "
        End If
    End Sub

    Private Sub RadioButton8_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton8.CheckedChanged
        If RadioButton8.Checked = True Then
            ans3 = " YES "
        End If
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox8.Clear()
        TextBox9.Clear()
        RadioButton1.Checked = False
        radbtn2.Checked = False
        RadioButton3.Checked = False
        RadioButton4.Checked = False
        RadioButton5.Checked = False
        RadioButton6.Checked = False
        RadioButton7.Checked = False
        RadioButton8.Checked = False

    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then
            gender = "Male"
        End If
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        If RadioButton4.Checked = True Then
            ans1 = " NO "
        End If
    End Sub

    Private Sub RadioButton5_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton5.CheckedChanged
        If RadioButton5.Checked = True Then
            ans2 = " NO "
        End If
    End Sub

    Private Sub RadioButton7_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton7.CheckedChanged
        If RadioButton7.Checked = True Then
            ans3 = " NO "
        End If
    End Sub
End Class
